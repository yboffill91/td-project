import { Sora, Inter } from 'next/font/google';

export const HeadeingsFonts = Sora({
  subsets: ['latin'],
  weight: ['400', '700'],
});

export const BodyFonts = Inter({
  subsets: ['latin'],
});

